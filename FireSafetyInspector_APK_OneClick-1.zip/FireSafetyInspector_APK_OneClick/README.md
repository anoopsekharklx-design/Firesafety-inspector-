# Fire Safety Inspector — APK-ready project

This project wraps the supplied mobile-friendly HTML app in a native Android WebView.
The HTML is already included at `app/src/main/assets/index.html`.

## Easiest one-click build: GitHub Actions

1. Create a GitHub repository.
2. Upload this entire project folder.
3. Open the repository's **Actions** tab.
4. Select **Build Fire Safety Inspector APK**.
5. Tap **Run workflow**.
6. When it finishes, open the workflow run and download the artifact named **FireSafetyInspector-APK**.
7. Extract it and install `app-debug.apk` on your Android phone.

No HTML or Android code changes are required.

## Local Android Studio build

Open this folder in Android Studio. If Android Studio asks for a Gradle distribution, use Gradle 8.9. Then choose **Build > Build APK(s)**. The APK will be under `app/build/outputs/apk/debug/`.

## Important

The generated debug APK is installable but is not a Play Store release-signed APK. A Play Store release build requires your own signing key.
