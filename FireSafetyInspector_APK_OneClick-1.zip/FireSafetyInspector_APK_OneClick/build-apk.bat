@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not installed or not on PATH.
  echo For the easiest method, upload this project to GitHub and run:
  echo Actions ^> Build Fire Safety Inspector APK ^> Run workflow
  pause
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo APK created at:
echo app\build\outputs\apk\debug\app-debug.apk
pause
